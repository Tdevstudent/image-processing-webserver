import sys
import requests
import json

# url of the api
site_path = 'http://127.0.0.1:5000'
api_path = site_path + '/api/'


def script_names():
    r = requests.get(api_path + 'script_names')
    return json.loads(r.text)


def preset_names():
    r = requests.get(api_path + 'preset_names')
    return json.loads(r.text)


def names():
    print("script names: " + str(script_names()))
    print("preset names: " + str(preset_names()))


def upload_image(image):
    files = {'image': open(image, 'rb')}
    print('uploading image...')
    r = requests.post(api_path + 'upload_image/', files=files)
    if r.status_code == 200:
        print('uploaded image')
        return r.text
    else:
        print('failed to upload image')


def remove_image(image):
    data = {'image': image}
    print('removing image...')
    r = requests.post(api_path + 'remove_image/', json=json.dumps(data))
    if r.status_code == 200:
        print('removed image')
        return r.text
    else:
        print('failed to remove image')


def custom_image():
    # upload image to obtain a key (server filename)
    key = upload_image('example_image.png')
    print("key = " + key)

    # remove image from the server using the key
    remove_image(key)


def request(script, image, preset, args):
    data = {'script': script, 'image': image, 'preset': preset}
    for name in args:
        data[name] = args[name]
    print("requesting image processing")
    r = requests.post(api_path, json=json.dumps(data))
    if r.status_code == 200:
        print("image processed")
        return r.text
    else:
        print("image processing failed")


def store_image(source, dest):
    r = requests.get(source)
    ext = source.split('.')[-1]
    if r.status_code == 200:
        print("storing resulting image as " + dest)
        file = open(dest + '.' + ext, 'wb')
        for chunk in r:
            file.write(chunk)
        file.close()
    else:
        print("failed to retrieve image")


def color():
    args = {'color': 'g'}
    url = site_path + request('color', 'girl.png', 'true', args)
    filename = 'response_image'
    store_image(url, filename)


examples = {'custom_image': custom_image,
            'color': color, 'names': names}

if __name__ == '__main__':
    try:
        examples[sys.argv[1]]()
    except KeyError:
        print('Invalid Example Name')
