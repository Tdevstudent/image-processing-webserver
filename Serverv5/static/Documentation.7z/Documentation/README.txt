If you are interested in using the python example code, use the Pipfile and Pipenv or a similar tool to install dependencies.

Keep in mind that uploaded images and their output are cleaned up periodically. If a script takes too long, or is not compatible with the input an error or no output may be returned.

Below is an overview of available API calls:


url: /api/preset_names/
HTTP method: GET
returns: a JSON list of available preset image names

url: /api/script_names/
HTTP method: GET
returns: a JSON list of available script names

url: /images/presets/[filename]/
HTTP method: GET
returns: a preset image if filename is in preset_names

url: /images/output/[filename]/
HTTP method: GET
returns: a processed output image if the filename exists

url: /api/upload_image
HTTP method: POST
expects: an image file
returns: a local server filename used to refer to the image

url: /api/remove_image
HTTP method: POST
expects: JSON object with a field 'image' containing the local server filename of the image to be removed
returns: confirmation message the file has been removed

url: /api/
HTTP method: POST
expects: a json file with the following data:
- script: string in script_names
- preset: True if image refers to an image in preset_image, False otherwise
- image: either a local server filename obtained through upload_image, or if Preset==True a string in preset_names
returns: a file path (string) referring to the location of the output image on the server